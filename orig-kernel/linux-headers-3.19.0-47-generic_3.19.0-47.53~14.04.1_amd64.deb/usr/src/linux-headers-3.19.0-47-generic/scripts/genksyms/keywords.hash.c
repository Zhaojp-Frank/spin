/* ANSI-C code produced by gperf version 3.0.4 */
/* Command-line: gperf -t --output-file scripts/genksyms/keywords.hash.c_shipped -a -C -E -g -k '1,3,$' -p -t scripts/genksyms/keywords.gperf  */

#if !((' ' == 32) && ('!' == 33) && ('"' == 34) && ('#' == 35) \
      && ('%' == 37) && ('&' == 38) && ('\'' == 39) && ('(' == 40) \
      && (')' == 41) && ('*' == 42) && ('+' == 43) && (',' == 44) \
      && ('-' == 45) && ('.' == 46) && ('/' == 47) && ('0' == 48) \
      && ('1' == 49) && ('2' == 50) && ('3' == 51) && ('4' == 52) \
      && ('5' == 53) && ('6' == 54) && ('7' == 55) && ('8' == 56) \
      && ('9' == 57) && (':' == 58) && (';' == 59) && ('<' == 60) \
      && ('=' == 61) && ('>' == 62) && ('?' == 63) && ('A' == 65) \
      && ('B' == 66) && ('C' == 67) && ('D' == 68) && ('E' == 69) \
      && ('F' == 70) && ('G' == 71) && ('H' == 72) && ('I' == 73) \
      && ('J' == 74) && ('K' == 75) && ('L' == 76) && ('M' == 77) \
      && ('N' == 78) && ('O' == 79) && ('P' == 80) && ('Q' == 81) \
      && ('R' == 82) && ('S' == 83) && ('T' == 84) && ('U' == 85) \
      && ('V' == 86) && ('W' == 87) && ('X' == 88) && ('Y' == 89) \
      && ('Z' == 90) && ('[' == 91) && ('\\' == 92) && (']' == 93) \
      && ('^' == 94) && ('_' == 95) && ('a' == 97) && ('b' == 98) \
      && ('c' == 99) && ('d' == 100) && ('e' == 101) && ('f' == 102) \
      && ('g' == 103) && ('h' == 104) && ('i' == 105) && ('j' == 106) \
      && ('k' == 107) && ('l' == 108) && ('m' == 109) && ('n' == 110) \
      && ('o' == 111) && ('p' == 112) && ('q' == 113) && ('r' == 114) \
      && ('s' == 115) && ('t' == 116) && ('u' == 117) && ('v' == 118) \
      && ('w' == 119) && ('x' == 120) && ('y' == 121) && ('z' == 122) \
      && ('{' == 123) && ('|' == 124) && ('}' == 125) && ('~' == 126))
/* The character set is not based on ISO-646.  */
#error "gperf generated tables don't work with this execution character set. Please report a bug to <bug-gnu-gperf@gnu.org>."
#endif

#line 4 "scripts/genksyms/keywords.gperf"

struct resword;
static const struct resword *is_reserved_word(register const char *str, register unsigned int len);
#line 8 "scripts/genksyms/keywords.gperf"
struct resword { const char *name; int token; };
/* maximum key range = 98, duplicates = 0 */

#ifdef __GNUC__
__inline
#else
#ifdef __cplusplus
inline
#endif
#endif
static unsigned int
is_reserved_hash (register const char *str, register unsigned int len)
{
  static const unsigned char asso_values[] =
    {
      101, 101, 101, 101, 101, 101, 101, 101, 101, 101,
      101, 101, 101, 101, 101, 101, 101, 101, 101, 101,
      101, 101, 101, 101, 101, 101, 101, 101, 101, 101,
      101, 101, 101, 101, 101, 101, 101, 101, 101, 101,
      101, 101, 101, 101, 101, 101, 101, 101, 101, 101,
      101, 101, 101, 101, 101, 101, 101, 101, 101, 101,
      101, 101, 101, 101, 101, 101, 101, 101, 101,   0,
      101, 101, 101, 101, 101, 101,  15, 101, 101, 101,
        0, 101, 101, 101, 101, 101, 101, 101, 101, 101,
      101, 101, 101, 101, 101,   0, 101,   0, 101,   5,
       25,  20,  55,  30, 101,  15, 101, 101,  10,   0,
       10,  40,  10, 101,  10,   5,   0,  10,  15, 101,
      101, 101, 101, 101, 101, 101, 101, 101, 101, 101,
      101, 101, 101, 101, 101, 101, 101, 101, 101, 101,
      101, 101, 101, 101, 101, 101, 101, 101, 101, 101,
      101, 101, 101, 101, 101, 101, 101, 101, 101, 101,
      101, 101, 101, 101, 101, 101, 101, 101, 101, 101,
      101, 101, 101, 101, 101, 101, 101, 101, 101, 101,
      101, 101, 101, 101, 101, 101, 101, 101, 101, 101,
      101, 101, 101, 101, 101, 101, 101, 101, 101, 101,
      101, 101, 101, 101, 101, 101, 101, 101, 101, 101,
      101, 101, 101, 101, 101, 101, 101, 101, 101, 101,
      101, 101, 101, 101, 101, 101, 101, 101, 101, 101,
      101, 101, 101, 101, 101, 101, 101, 101, 101, 101,
      101, 101, 101, 101, 101, 101, 101, 101, 101, 101,
      101, 101, 101, 101, 101, 101
    };
  return len + asso_values[(unsigned char)str[2]] + asso_values[(unsigned char)str[0]] + asso_values[(unsigned char)str[len - 1]];
}

#ifdef __GNUC__
__inline
#if defined __GNUC_STDC_INLINE__ || defined __GNUC_GNU_INLINE__
__attribute__ ((__gnu_inline__))
#endif
#endif
const struct resword *
is_reserved_word (register const char *str, register unsigned int len)
{
  enum
    {
      TOTAL_KEYWORDS = 46,
      MIN_WORD_LENGTH = 3,
      MAX_WORD_LENGTH = 24,
      MIN_HASH_VALUE = 3,
      MAX_HASH_VALUE = 100
    };

  static const struct resword wordlist[] =
    {
      {""}, {""}, {""},
#line 35 "scripts/genksyms/keywords.gperf"
      {"asm", ASM_KEYW},
      {""},
#line 15 "scripts/genksyms/keywords.gperf"
      {"__asm", ASM_KEYW},
      {""},
#line 16 "scripts/genksyms/keywords.gperf"
      {"__asm__", ASM_KEYW},
      {""}, {""},
#line 27 "scripts/genksyms/keywords.gperf"
      {"__typeof__", TYPEOF_KEYW},
      {""},
#line 19 "scripts/genksyms/keywords.gperf"
      {"__const", CONST_KEYW},
#line 18 "scripts/genksyms/keywords.gperf"
      {"__attribute__", ATTRIBUTE_KEYW},
#line 20 "scripts/genksyms/keywords.gperf"
      {"__const__", CONST_KEYW},
#line 25 "scripts/genksyms/keywords.gperf"
      {"__signed__", SIGNED_KEYW},
#line 53 "scripts/genksyms/keywords.gperf"
      {"static", STATIC_KEYW},
      {""},
#line 48 "scripts/genksyms/keywords.gperf"
      {"int", INT_KEYW},
#line 41 "scripts/genksyms/keywords.gperf"
      {"char", CHAR_KEYW},
#line 42 "scripts/genksyms/keywords.gperf"
      {"const", CONST_KEYW},
#line 54 "scripts/genksyms/keywords.gperf"
      {"struct", STRUCT_KEYW},
#line 33 "scripts/genksyms/keywords.gperf"
      {"__restrict__", RESTRICT_KEYW},
#line 34 "scripts/genksyms/keywords.gperf"
      {"restrict", RESTRICT_KEYW},
#line 12 "scripts/genksyms/keywords.gperf"
      {"EXPORT_SYMBOL_GPL_FUTURE", EXPORT_SYMBOL_KEYW},
#line 23 "scripts/genksyms/keywords.gperf"
      {"__inline__", INLINE_KEYW},
      {""},
#line 29 "scripts/genksyms/keywords.gperf"
      {"__volatile__", VOLATILE_KEYW},
#line 10 "scripts/genksyms/keywords.gperf"
      {"EXPORT_SYMBOL", EXPORT_SYMBOL_KEYW},
#line 32 "scripts/genksyms/keywords.gperf"
      {"_restrict", RESTRICT_KEYW},
      {""},
#line 17 "scripts/genksyms/keywords.gperf"
      {"__attribute", ATTRIBUTE_KEYW},
#line 11 "scripts/genksyms/keywords.gperf"
      {"EXPORT_SYMBOL_GPL", EXPORT_SYMBOL_KEYW},
#line 21 "scripts/genksyms/keywords.gperf"
      {"__extension__", EXTENSION_KEYW},
#line 44 "scripts/genksyms/keywords.gperf"
      {"enum", ENUM_KEYW},
#line 13 "scripts/genksyms/keywords.gperf"
      {"EXPORT_UNUSED_SYMBOL", EXPORT_SYMBOL_KEYW},
#line 45 "scripts/genksyms/keywords.gperf"
      {"extern", EXTERN_KEYW},
      {""},
#line 24 "scripts/genksyms/keywords.gperf"
      {"__signed", SIGNED_KEYW},
#line 14 "scripts/genksyms/keywords.gperf"
      {"EXPORT_UNUSED_SYMBOL_GPL", EXPORT_SYMBOL_KEYW},
#line 57 "scripts/genksyms/keywords.gperf"
      {"union", UNION_KEYW},
      {""}, {""},
#line 22 "scripts/genksyms/keywords.gperf"
      {"__inline", INLINE_KEYW},
#line 40 "scripts/genksyms/keywords.gperf"
      {"auto", AUTO_KEYW},
#line 28 "scripts/genksyms/keywords.gperf"
      {"__volatile", VOLATILE_KEYW},
      {""}, {""},
#line 58 "scripts/genksyms/keywords.gperf"
      {"unsigned", UNSIGNED_KEYW},
      {""},
#line 51 "scripts/genksyms/keywords.gperf"
      {"short", SHORT_KEYW},
#line 47 "scripts/genksyms/keywords.gperf"
      {"inline", INLINE_KEYW},
      {""},
#line 60 "scripts/genksyms/keywords.gperf"
      {"volatile", VOLATILE_KEYW},
#line 49 "scripts/genksyms/keywords.gperf"
      {"long", LONG_KEYW},
#line 31 "scripts/genksyms/keywords.gperf"
      {"_Bool", BOOL_KEYW},
      {""}, {""},
#line 50 "scripts/genksyms/keywords.gperf"
      {"register", REGISTER_KEYW},
#line 59 "scripts/genksyms/keywords.gperf"
      {"void", VOID_KEYW},
      {""},
#line 43 "scripts/genksyms/keywords.gperf"
      {"double", DOUBLE_KEYW},
      {""},
#line 26 "scripts/genksyms/keywords.gperf"
      {"__typeof", TYPEOF_KEYW},
      {""}, {""},
#line 52 "scripts/genksyms/keywords.gperf"
      {"signed", SIGNED_KEYW},
      {""}, {""}, {""}, {""},
#line 56 "scripts/genksyms/keywords.gperf"
      {"typeof", TYPEOF_KEYW},
#line 55 "scripts/genksyms/keywords.gperf"
      {"typedef", TYPEDEF_KEYW},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 46 "scripts/genksyms/keywords.gperf"
      {"float", FLOAT_KEYW}
    };

  if (len <= MAX_WORD_LENGTH && len >= MIN_WORD_LENGTH)
    {
      register int key = is_reserved_hash (str, len);

      if (key <= MAX_HASH_VALUE && key >= 0)
        {
          register const char *s = wordlist[key].name;

          if (*str == *s && !strcmp (str + 1, s + 1))
            return &wordlist[key];
        }
    }
  return 0;
}
